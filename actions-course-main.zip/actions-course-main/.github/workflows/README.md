# Workflows

1)  Workflows are defined in .github/workflows directory.
2)  The file name is the name of the workflow.
3)  The file is in YAML format.

