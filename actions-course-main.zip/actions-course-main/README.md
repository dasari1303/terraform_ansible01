# GitHub Actions Fundamentals

1) Click the _USE THIS TEMPLATE_ button to create a personal repository based off of this repository.
2) Name the repository actions-course-\<_your GitHub handle_\>.
3) Set the visibility to `public` for accounts, `internal` for corporate with GHAS.
