# Samples

Copy a sample of interest into the .github/workflows folder.


